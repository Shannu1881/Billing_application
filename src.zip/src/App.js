import React from 'react';
import Data from './components/data';
import Items from './components/items';
import img from "./wallpaper.jpg";

const App = () => {
  return (
    <div style={{backgroundColor:'black'}}>
       <Data />
    </div>
  )
}

export default App