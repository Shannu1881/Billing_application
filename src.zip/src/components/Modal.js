import React from 'react'

const Modal = () => {
  return (
    <div>Modal</div>
  )
}

export default Modal